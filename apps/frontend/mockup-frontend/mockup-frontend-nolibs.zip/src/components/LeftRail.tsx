import { NavLink } from 'react-router-dom'
import { useState } from 'react'

const Item = ({ to, label, icon }: { to: string; label: string; icon: string }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `group flex h-16 w-12 flex-col items-center justify-start rounded-md text-[var(--lpc-primary)] hover:bg-[var(--lpc-bg)] focus:outline-none focus:ring-2 focus:ring-[var(--lpc-link)] ${isActive ? 'bg-[var(--lpc-bg)]' : ''}`
    }
    aria-label={label}
  >
    <span className="text-xl mt-1" aria-hidden>
      {icon}
    </span>
    <span className="mt-1 text-[10px] leading-tight text-[var(--lpc-muted)] text-center">
      {label}
    </span>
  </NavLink>
)

export default function LeftRail() {
  const [expanded, setExpanded] = useState(false)
  return (
    <aside className={`hidden md:flex md:flex-col items-center sticky top-14 h-[calc(100vh-56px)] overflow-y-auto bg-white border-r border-[var(--lpc-stroke)] pt-3 px-2 gap-3 transition-[width] duration-200 ${expanded ? 'w-24' : 'w-14'}`} aria-label="Primary">
      <button
        className="flex h-10 w-10 items-center justify-center rounded-md text-[var(--lpc-primary)] hover:bg-[var(--lpc-bg)] focus:outline-none focus:ring-2 focus:ring-[var(--lpc-link)]"
        aria-label={expanded ? 'Collapse menu' : 'Expand menu'}
        aria-expanded={expanded}
        onClick={() => setExpanded((v) => !v)}
      >
        <span aria-hidden className="text-xl">≡</span>
      </button>
      <Item to="/apply" label="Apply" icon="➕" />
      <Item to="/applications" label="My Apps" icon="📄" />
      <Item to="/help" label="Help" icon="❓" />
      <Item to="/notifications" label="Alerts" icon="🔔" />
    </aside>
  )
}


