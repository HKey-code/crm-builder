export default function HeroBanner() {
  return (
    <div
      className="relative overflow-hidden rounded-md shadow-sm h-28 md:h-36 mb-4 bg-center bg-cover"
      style={{
        backgroundImage:
          "linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0)), url(/Hero.png?v=2), url(/hero.jpg?v=2)",
      }}
      aria-hidden="true"
    />
  )
}


