export default function Footer() {
  return (
    <footer className="mt-10 border-t bg-white">
      <div className="h-3 w-full bg-[var(--lpc-link)]" aria-hidden />
      <div className="mx-auto max-w-6xl px-4 py-6 text-sm text-lpc.muted flex items-center justify-between">
        <div>© {new Date().getFullYear()} NebuLogic</div>
        <nav className="flex gap-4">
          <a className="hover:underline" href="#">Accessibility</a>
          <a className="hover:underline" href="#">Privacy</a>
          <a className="hover:underline" href="#">Contact</a>
        </nav>
      </div>
    </footer>
  )
}


