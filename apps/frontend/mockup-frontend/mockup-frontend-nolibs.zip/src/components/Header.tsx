import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import Logo from './Logo'
import { RightDrawer } from './RightDrawer'
import { useComm } from '../comm/CommContext'

export const Header: React.FC = () => {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [avatarOpen, setAvatarOpen] = useState(false)
  const { notifications, unreadCount } = useComm()

  return (
    <header className="sticky top-0 z-50 w-full bg-[var(--lpc-bg)] text-[var(--lpc-text)] shadow">
      <div className="h-3 w-full bg-[var(--lpc-link)]" aria-hidden />
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link to="/applications" className="focus:outline-none focus:ring-2 focus:ring-lpc-accent/70 rounded">
            <Logo src="/lpc-logo.svg" />
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <NavLink to="/apply" className={({ isActive }) => `focus:outline-none focus:ring-2 focus:ring-lpc-accent/70 rounded hover:text-[var(--lpc-link)] ${isActive ? 'underline' : 'hover:underline'}`}>Apply</NavLink>
            <NavLink to="/applications" className={({ isActive }) => `focus:outline-none focus:ring-2 focus:ring-lpc-accent/70 rounded hover:text-[var(--lpc-link)] ${isActive ? 'underline' : 'hover:underline'}`}>My Applications</NavLink>
            <NavLink to="/help" className={({ isActive }) => `focus:outline-none focus:ring-2 focus:ring-lpc-accent/70 rounded hover:text-[var(--lpc-link)] ${isActive ? 'underline' : 'hover:underline'}`}>Help</NavLink>
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <button aria-label="Notifications" className="relative focus:outline-none focus:ring-2 focus:ring-lpc-accent/70 rounded" onClick={() => setDrawerOpen(true)}>
            <span aria-hidden>🔔</span>
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 inline-flex h-2.5 w-2.5 rounded-full bg-lpc-accent" />
            )}
          </button>
          <div className="relative">
            <button
              aria-label="Account menu"
              className="ml-2 h-8 w-8 rounded-full bg-white/20 grid place-items-center"
              onClick={() => setAvatarOpen((v) => !v)}
            >
              U
            </button>
            {avatarOpen && (
              <div role="menu" className="absolute right-0 mt-2 w-40 overflow-hidden rounded-md border bg-white shadow-lg">
                <Link to="/profile" className="block px-3 py-2 text-sm hover:bg-lpc-bg" onClick={() => setAvatarOpen(false)}>Profile</Link>
                <button className="block w-full px-3 py-2 text-left text-sm hover:bg-lpc-bg" onClick={() => setAvatarOpen(false)}>Logout</button>
              </div>
            )}
          </div>
        </div>
      </div>
      <RightDrawer title="Notifications" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <ul className="space-y-3" aria-label="Notifications list">
          {notifications.map((n) => (
            <li key={n.id} className="flex items-start gap-3">
              <span className={`mt-1 inline-block h-2 w-2 rounded-full ${n.unread ? 'bg-lpc-accent' : 'bg-gray-300'}`} aria-hidden />
              <div>
                <p className="text-sm text-lpc-text">{n.title}</p>
                <p className="text-xs text-gray-500">{n.time}</p>
              </div>
            </li>
          ))}
        </ul>
      </RightDrawer>
    </header>
  )
}

export default Header


