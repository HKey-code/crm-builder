export function FooterAccent() {
  return <div role="presentation" aria-hidden="true" className="w-full h-1.5 bg-[#1C6EA4]" />
}

export default FooterAccent


