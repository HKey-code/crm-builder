import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import MockLayout from './layouts/MockLayout'
import ApplyPage from './pages/Apply'
import ApplicationsPage from './pages/Applications'
import ApplicationDetailsPage from './pages/ApplicationDetails'
import HelpPage from './pages/Help'
import NotificationsPage from './pages/Notifications'

function App() {
  const router = createBrowserRouter([
    {
      element: <MockLayout />,
      children: [
        { path: '/', element: <ApplicationsPage /> },
        { path: '/apply', element: <ApplyPage /> },
        { path: '/applications', element: <ApplicationsPage /> },
        { path: '/applications/:id', element: <ApplicationDetailsPage /> },
        { path: '/help', element: <HelpPage /> },
        { path: '/notifications', element: <NotificationsPage /> },
      ],
    },
  ])

  return <RouterProvider router={router} />
}

export default App
