import { Outlet, useLocation } from 'react-router-dom'
import Header from '../components/Header'
import { CommProvider } from '../comm/CommContext'
import Footer from '../components/Footer'
import FooterAccent from '../components/FooterAccent'
import LeftRail from '../components/LeftRail'
import HeroBanner from '../components/HeroBanner'
// import { useLocation } from 'react-router-dom'

export default function MockLayout() {
  const location = useLocation()
  const pathname = location.pathname
  const showHero = pathname === '/' || pathname.startsWith('/applications') || pathname.startsWith('/apply')
  return (
    <CommProvider>
      <div className="min-h-dvh flex flex-col bg-[var(--lpc-bg,#F2F6FA)] text-[var(--lpc-text,#263442)]">
        <Header />
        <div className="flex-1 grid grid-cols-[auto,1fr] gap-4 mt-2">
          <LeftRail />
          <main className="px-4 py-4 mx-auto w-full max-w-6xl">
            {showHero && <HeroBanner />}
            <Outlet />
          </main>
        </div>
        <Footer />
        <FooterAccent />
      </div>
    </CommProvider>
  )
}


