import React from 'react'
import { applications } from '../mock-data'
import SummaryCard from '../components/SummaryCard'
import DataTable from '../components/DataTable'
import { Link } from 'react-router-dom'

export const ApplicationsPage: React.FC = () => {
  const inProgress = applications.filter((a) => a.status === 'In Review' || a.status === 'Submitted').length
  const inspections = applications.filter((a) => a.status === 'Awaiting Inspection').length
  const paymentsDue = 1

  return (
    <div className="mx-auto max-w-6xl p-4">
      <div className="mb-2" />
      <h1 className="mb-4 text-2xl font-semibold text-lpc-primary">My Applications</h1>
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <SummaryCard label="Applications in Progress" count={inProgress} />
        <SummaryCard label="Inspections Scheduled" count={inspections} />
        <SummaryCard label="Payments Due" count={paymentsDue} />
      </div>
      <DataTable
        columns={[
          { key: 'id', header: 'ID' },
          { key: 'type', header: 'Type' },
          { key: 'status', header: 'Status' },
          { key: 'submittedAt', header: 'Submitted' },
          { key: 'id', header: 'Actions', render: (row: any) => <Link className="text-lpc-secondary underline" to={`/applications/${row.id}`}>View</Link> },
        ]}
        rows={applications}
      />
    </div>
  )
}

export default ApplicationsPage


